This is a simple test 
(although it checks a lot of things that might be important)
im not a scripting expert :(

how to run:
*************

1. put the following files in a folder and put a copy of your 
prf.c file in the folder

2. run the following lines:
chmod 700 run
./run

*************

*you can check the content of the tests with with objdump -d test_name.out

if there are any problems in the test please let me know!!!





